﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyServiseB.ClassHelper
{
    public class AppDate
    {
        public static EF3.Entities Context { get; } = new EF3.Entities();
    }
}
